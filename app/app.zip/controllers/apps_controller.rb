class AppsController < ApplicationController
	
	#before_action :authenticate_with_token!

	def index
	
	end
	
    def show
    
    @mobile_app = {
      :title => " Tutorial",
      :descr => " app",
      :rating => "*****"
    }
    render "show.js.erb"
    end
	
	def form_one
	
	end
	

end
